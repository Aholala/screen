#include "LCD_Driver.h"
#include "Delay.h"

// Ӳ��SPI�����ֽ�
void SPI1_SendByte(uint8_t data)
{
    while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET);
    SPI_I2S_SendData(SPI1, data);
    
    while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_RXNE) == RESET);
    SPI_I2S_ReceiveData(SPI1);
}

// ��ʼ��GPIO��SPI1
void LCD_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    SPI_InitTypeDef SPI_InitStructure;  // �� ��ȷ����

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_SPI1, ENABLE);

    // === SPI1 ���ţ�PA5 (SCK), PA7 (MOSI) ===
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5 | GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // === �������ţ�PB0, PB1, PB10, PB11 ===
    GPIO_InitStructure.GPIO_Pin = LCD_RST_PIN | LCD_RS_PIN | LCD_CS_PIN | LCD_LED_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    // ��ʼ״̬
    LCD_CS_SET;
    LCD_RS_SET;
    LCD_RST_SET;
    LCD_LED_SET;

    // === ����SPI1 ===
    SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
    SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
    SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
    SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
    SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
    SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
    SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_8;  // 9MHz
    SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
    SPI_InitStructure.SPI_CRCPolynomial = 7;
    SPI_Init(SPI1, &SPI_InitStructure);

    SPI_Cmd(SPI1, ENABLE);
}

// д����
void LCD_WriteIndex(uint8_t reg)
{
    LCD_CS_CLR;
    LCD_RS_CLR;
    SPI1_SendByte(reg);
    LCD_CS_SET;
}

// д���ݣ�8λ��
void LCD_WriteData(uint8_t data)
{
    LCD_CS_CLR;
    LCD_RS_SET;
    SPI1_SendByte(data);
    LCD_CS_SET;
}

// д16λ���ݣ�RGB565��
void LCD_WriteData_16Bit(uint16_t data)
{
    LCD_CS_CLR;
    LCD_RS_SET;
    SPI1_SendByte(data >> 8);
    SPI1_SendByte(data & 0xFF);
    LCD_CS_SET;
}

// д�Ĵ���
void LCD_WriteReg(uint8_t reg, uint8_t data)
{
    LCD_WriteIndex(reg);
    LCD_WriteData(data);
}

// ������ʾ����
void LCD_SetRegion(uint16_t x_start, uint16_t y_start, uint16_t x_end, uint16_t y_end)
{
    LCD_WriteIndex(0x2A);
    LCD_CS_CLR;
    LCD_RS_SET;
    SPI1_SendByte(x_start >> 8);
    SPI1_SendByte(x_start & 0xFF);
    SPI1_SendByte(x_end >> 8);
    SPI1_SendByte(x_end & 0xFF);
    LCD_CS_SET;

    LCD_WriteIndex(0x2B);
    LCD_CS_CLR;
    LCD_RS_SET;
    SPI1_SendByte(y_start >> 8);
    SPI1_SendByte(y_start & 0xFF);
    SPI1_SendByte(y_end >> 8);
    SPI1_SendByte(y_end & 0xFF);
    LCD_CS_SET;

    LCD_WriteIndex(0x2C);
}

// ��������
void LCD_SetXY(uint16_t x, uint16_t y)
{
    LCD_SetRegion(x, y, x, y);
}

// ��λLCD
void LCD_Reset(void)
{
    LCD_RST_CLR;
    Delay_ms(100);
    LCD_RST_SET;
    Delay_ms(120);
}

// ��ʼ��ST7735S
void LCD_Init(void)
{
    LCD_GPIO_Init();
    LCD_Reset();

    LCD_WriteIndex(0x11); Delay_ms(120);

    LCD_WriteIndex(0xB1); LCD_WriteData(0x01); LCD_WriteData(0x2C); LCD_WriteData(0x2D);
    LCD_WriteIndex(0xB2); LCD_WriteData(0x01); LCD_WriteData(0x2C); LCD_WriteData(0x2D);
    LCD_WriteIndex(0xB3); LCD_WriteData(0x01); LCD_WriteData(0x2C); LCD_WriteData(0x2D); LCD_WriteData(0x01); LCD_WriteData(0x2C); LCD_WriteData(0x2D);
    LCD_WriteIndex(0xB4); LCD_WriteData(0x07);
    LCD_WriteIndex(0xC0); LCD_WriteData(0xA2); LCD_WriteData(0x02); LCD_WriteData(0x84);
    LCD_WriteIndex(0xC1); LCD_WriteData(0xC5);
    LCD_WriteIndex(0xC2); LCD_WriteData(0x0A); LCD_WriteData(0x00);
    LCD_WriteIndex(0xC3); LCD_WriteData(0x8A); LCD_WriteData(0x2A);
    LCD_WriteIndex(0xC4); LCD_WriteData(0x8A); LCD_WriteData(0xEE);
    LCD_WriteIndex(0xC5); LCD_WriteData(0x0E);
    LCD_WriteIndex(0x36); LCD_WriteData(0xC0);
    LCD_WriteIndex(0xE0); LCD_WriteData(0x0F); LCD_WriteData(0x1A); LCD_WriteData(0x0F); LCD_WriteData(0x18); LCD_WriteData(0x2F); LCD_WriteData(0x28); LCD_WriteData(0x20); LCD_WriteData(0x22); LCD_WriteData(0x1F); LCD_WriteData(0x1B); LCD_WriteData(0x23); LCD_WriteData(0x37); LCD_WriteData(0x00); LCD_WriteData(0x07); LCD_WriteData(0x02); LCD_WriteData(0x10);
    LCD_WriteIndex(0xE1); LCD_WriteData(0x0F); LCD_WriteData(0x1B); LCD_WriteData(0x0F); LCD_WriteData(0x17); LCD_WriteData(0x33); LCD_WriteData(0x2C); LCD_WriteData(0x29); LCD_WriteData(0x2E); LCD_WriteData(0x30); LCD_WriteData(0x30); LCD_WriteData(0x39); LCD_WriteData(0x3F); LCD_WriteData(0x00); LCD_WriteData(0x07); LCD_WriteData(0x03); LCD_WriteData(0x10);
    LCD_WriteIndex(0x3A); LCD_WriteData(0x05);
    LCD_WriteIndex(0x29); // Display ON
    LCD_LED_SET;
}

// ����
void LCD_Clear(uint16_t color)
{
    uint32_t total = X_MAX_PIXEL * Y_MAX_PIXEL;
    uint8_t high = (uint8_t)(color >> 8);
    uint8_t low  = (uint8_t)(color & 0xFF);

    LCD_SetRegion(0, 0, X_MAX_PIXEL - 1, Y_MAX_PIXEL - 1);
    LCD_CS_CLR;
    LCD_RS_SET;

    for (uint32_t i = 0; i < total; i++)
    {
        SPI1_SendByte(high);
        SPI1_SendByte(low);
    }

    LCD_CS_SET;
}

// ����
void Gui_DrawPoint(uint16_t x, uint16_t y, uint16_t color)
{
    if (x >= X_MAX_PIXEL || y >= Y_MAX_PIXEL) return;
    LCD_SetXY(x, y);
    LCD_WriteData_16Bit(color);
}
