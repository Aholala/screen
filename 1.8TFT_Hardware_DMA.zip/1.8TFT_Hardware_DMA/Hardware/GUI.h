#ifndef __GUI_H
#define __GUI_H

#include "stm32f10x.h"                  // Device header

// ��ɫת��
u16 LCD_BGR2RGB(u16 c);

// ͼ�λ���
void Gui_Circle(u16 X, u16 Y, u16 R, u16 fc);
void Gui_DrawLine(u16 x0, u16 y0, u16 x1, u16 y1, u16 Color);
void Gui_Box(u16 x, u16 y, u16 w, u16 h, u16 bc);
void Gui_FillBox(u16 x, u16 y, u16 w, u16 h, u16 color);
void Gui_DrawPoint(uint16_t x, uint16_t y, uint16_t color);


// ��������ʾ
void Gui_DrawFont_GBK16(u16 x, u16 y, u16 fc, u16 bc, u8 *s);
void Gui_DrawFont_GBK24(u16 x, u16 y, u16 fc, u16 bc, u8 *s);
void Gui_DrawFont_Num32(u16 x, u16 y, u16 fc, u16 bc, u16 num);

// ͼƬ��ʾ
void Gui_ShowImage(const unsigned char *p, u16 w, u16 h, u16 x, u16 y);

#endif
