#include "stm32f10x.h"                  // Device header

#include "Lcd_Driver.h"
#include "GUI.h"
#include "Font.h"

// ��ɫת����������ͼƬ��BGR��ʽ�����ô˺���תΪRGB
u16 LCD_BGR2RGB(u16 c)
{
    u16 r, g, b, rgb;   
    b = (c >> 0) & 0x1f;
    g = (c >> 5) & 0x3f;
    r = (c >> 11) & 0x1f;	 
    rgb = (b << 11) + (g << 5) + (r << 0);		 
    return(rgb);
}

// ��Բ (Bresenham�㷨)
void Gui_Circle(u16 X, u16 Y, u16 R, u16 fc) 
{ 
    unsigned short a, b; 
    int c; 
    a = 0; 
    b = R; 
    c = 3 - 2 * R; 
    while (a < b) 
    { 
        Gui_DrawPoint(X+a, Y+b, fc);
        Gui_DrawPoint(X-a, Y+b, fc);
        Gui_DrawPoint(X+a, Y-b, fc);
        Gui_DrawPoint(X-a, Y-b, fc);
        Gui_DrawPoint(X+b, Y+a, fc);
        Gui_DrawPoint(X-b, Y+a, fc);
        Gui_DrawPoint(X+b, Y-a, fc);
        Gui_DrawPoint(X-b, Y-a, fc); 

        if(c < 0) c = c + 4 * a + 6; 
        else 
        { 
            c = c + 4 * (a - b) + 10; 
            b -= 1; 
        } 
        a += 1; 
    } 
    if (a == b) 
    { 
        Gui_DrawPoint(X+a, Y+b, fc); 
        Gui_DrawPoint(X+a, Y-b, fc); 
        Gui_DrawPoint(X-a, Y-b, fc); 
        Gui_DrawPoint(X+b, Y+a, fc); 
        Gui_DrawPoint(X-b, Y+a, fc); 
        Gui_DrawPoint(X+b, Y-a, fc); 
        Gui_DrawPoint(X-b, Y-a, fc); 
    } 
} 

// ���� (Bresenham�㷨)
void Gui_DrawLine(u16 x0, u16 y0, u16 x1, u16 y1, u16 Color)   
{
    int dx, dy, dx2, dy2, x_inc, y_inc, error, index;          

    dx = x1 - x0;
    dy = y1 - y0;

    if (dx >= 0) x_inc = 1;
    else { x_inc = -1; dx = -dx; } 
    
    if (dy >= 0) y_inc = 1; 
    else { y_inc = -1; dy = -dy; } 

    dx2 = dx << 1;
    dy2 = dy << 1;

    if (dx > dy)
    {
        error = dy2 - dx; 
        for (index = 0; index <= dx; index++)
        {
            Gui_DrawPoint(x0, y0, Color);
            if (error >= 0) 
            {
                error -= dx2;
                y0 += y_inc;
            } 
            error += dy2;
            x0 += x_inc;
        } 
    } 
    else
    {
        error = dx2 - dy; 
        for (index = 0; index <= dy; index++)
        {
            Gui_DrawPoint(x0, y0, Color);
            if (error >= 0)
            {
                error -= dy2;
                x0 += x_inc;
            } 
            error += dx2;
            y0 += y_inc;
        } 
    }
}

// ����
void Gui_Box(u16 x, u16 y, u16 w, u16 h, u16 bc)
{
    // �ϱ߿�
    Gui_DrawLine(x, y, x + w - 1, y, bc);
    // �ұ߿�
    Gui_DrawLine(x + w - 1, y, x + w - 1, y + h - 1, bc);
    // �±߿�
    Gui_DrawLine(x, y + h - 1, x + w - 1, y + h - 1, bc);
    // ��߿�
    Gui_DrawLine(x, y, x, y + h - 1, bc);
}
//ʵ�ķ���
void Gui_FillBox(u16 x, u16 y, u16 w, u16 h, u16 color)
{
    u32 i;
    u32 total = (u32)w * h;

    LCD_SetRegion(x, y, x + w - 1, y + h - 1);
    for (i = 0; i < total; i++)
    {
        LCD_WriteData_16Bit(color);
    }
}
// 16*16 GBK����/ASCII��ʾ
void Gui_DrawFont_GBK16(u16 x, u16 y, u16 fc, u16 bc, u8 *s)
{
    unsigned char i, j;
    unsigned short k, x0;
    x0 = x;

    while(*s) 
    {	
        if((*s) < 128) // ASCII
        {
            k = *s;
            if (k == 13) // ����
            {
                x = x0; y += 16;
            }
            else 
            {
                if (k > 32) k -= 32; else k = 0;
                for(i = 0; i < 16; i++) {
                    for(j = 0; j < 8; j++) {
                        if(asc16[k*16+i] & (0x80 >> j)) Gui_DrawPoint(x + j, y + i, fc);
                        else if (fc != bc) Gui_DrawPoint(x + j, y + i, bc);
                    }
                }
                x += 8;
            }
            s++;
        }
        else // ����
        {
            for (k = 0; k < hz16_num; k++) 
            {
                if ((hz16[k].Index[0] == *(s)) && (hz16[k].Index[1] == *(s+1)))
                { 
                    for(i = 0; i < 16; i++)
                    {
                        for(j = 0; j < 8; j++) {
                            if(hz16[k].Msk[i*2] & (0x80 >> j)) Gui_DrawPoint(x + j, y + i, fc);
                            else if (fc != bc) Gui_DrawPoint(x + j, y + i, bc);
                        }
                        for(j = 0; j < 8; j++) {
                            if(hz16[k].Msk[i*2+1] & (0x80 >> j)) Gui_DrawPoint(x + j + 8, y + i, fc);
                            else if (fc != bc) Gui_DrawPoint(x + j + 8, y + i, bc);
                        }
                    }
                }
            }
            s += 2; x += 16;
        } 
    }
}

// 24*24 GBK������ʾ
void Gui_DrawFont_GBK24(u16 x, u16 y, u16 fc, u16 bc, u8 *s)
{
    unsigned char i, j;
    unsigned short k;

    while(*s) 
    {
        if( *s < 0x80 ) // ASCII
        {
            // ע�⣺���ｨ������ asc24 ���壬���û�У���ά��ԭ���򱨴�
            k = *s;
            if (k > 32) k -= 32; else k = 0;
            for(i = 0; i < 16; i++) { // ��ʱ��16�ߵ�ASCII���
                for(j = 0; j < 8; j++) {
                    if(asc16[k*16+i] & (0x80 >> j)) Gui_DrawPoint(x + j, y + i, fc);
                    else if (fc != bc) Gui_DrawPoint(x + j, y + i, bc);
                }
            }
            s++; x += 8;
        }
        else // ����
        {
            for (k = 0; k < hz24_num; k++) 
            {
                if ((hz24[k].Index[0] == *(s)) && (hz24[k].Index[1] == *(s+1)))
                { 
                    for(i = 0; i < 24; i++)
                    {
                        for(j = 0; j < 8; j++) {
                            if(hz24[k].Msk[i*3] & (0x80 >> j)) Gui_DrawPoint(x + j, y + i, fc);
                            else if (fc != bc) Gui_DrawPoint(x + j, y + i, bc);
                        }
                        for(j = 0; j < 8; j++) {
                            if(hz24[k].Msk[i*3+1] & (0x80 >> j)) Gui_DrawPoint(x + j + 8, y + i, fc);
                            else if (fc != bc) Gui_DrawPoint(x + j + 8, y + i, bc);
                        }
                        for(j = 0; j < 8; j++) {
                            if(hz24[k].Msk[i*3+2] & (0x80 >> j)) Gui_DrawPoint(x + j + 16, y + i, fc);
                            else if (fc != bc) Gui_DrawPoint(x + j + 16, y + i, bc);
                        }
                    }
                }
            }
            s += 2; x += 24;
        }
    }
}

// ��ʾͼƬ
// p: ͼƬ����ָ��, w: ����, h: �߶�, x: ��ʼx, y: ��ʼy
void Gui_ShowImage(const unsigned char *p, u16 w, u16 h, u16 x, u16 y)
{
    u32 i;
    u16 picData;
    
    LCD_SetRegion(x, y, x + w - 1, y + h - 1);
    
    for(i = 0; i < w * h; i++)
    {	
        // ����ͼƬ������ Little-Endian (��λ��ǰ)
        // ���ͼƬ��ɫ��ת������� p[i*2] �� p[i*2+1] ��λ��
        picData = (*(p + i * 2 + 1) << 8) | (*(p + i * 2));
        LCD_WriteData_16Bit(picData);  						
    }		
}
