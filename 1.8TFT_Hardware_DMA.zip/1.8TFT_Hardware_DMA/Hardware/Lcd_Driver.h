#ifndef __LCD_DRIVER_H
#define __LCD_DRIVER_H

#include "stm32f10x.h"

// ��Ļ�ֱ���
#define X_MAX_PIXEL     128
#define Y_MAX_PIXEL     160

// ��ɫ���壨RGB565��
#define RED     0xF800
#define GREEN   0x07E0
#define BLUE    0x001F
#define WHITE   0xFFFF
#define BLACK   0x0000
#define YELLOW  0xFFE0
#define GRAY0   0xEF7D
#define GRAY1   0x8410
#define GRAY2   0x4208

// �������ţ�PB��
#define LCD_RST_PIN     GPIO_Pin_0   // PB0
#define LCD_RS_PIN      GPIO_Pin_1   // PB1 (DC)
#define LCD_CS_PIN      GPIO_Pin_10  // PB10
#define LCD_LED_PIN     GPIO_Pin_11  // PB11

// ���ƺ�
#define LCD_RST_SET     GPIOB->BSRR = LCD_RST_PIN
#define LCD_RST_CLR     GPIOB->BRR  = LCD_RST_PIN

#define LCD_RS_SET      GPIOB->BSRR = LCD_RS_PIN
#define LCD_RS_CLR      GPIOB->BRR  = LCD_RS_PIN

#define LCD_CS_SET      GPIOB->BSRR = LCD_CS_PIN
#define LCD_CS_CLR      GPIOB->BRR  = LCD_CS_PIN

#define LCD_LED_SET     GPIOB->BSRR = LCD_LED_PIN
#define LCD_LED_CLR     GPIOB->BRR  = LCD_LED_PIN

// ��������
void LCD_GPIO_Init(void);
void LCD_DMA_Init(void);
void LCD_Reset(void);
void LCD_Init(void);
void LCD_WriteIndex(uint8_t reg);
void LCD_WriteData(uint8_t data);
void LCD_WriteData_16Bit(uint16_t data);
void LCD_WriteReg(uint8_t reg, uint8_t data);
void LCD_SetRegion(uint16_t x_start, uint16_t y_start, uint16_t x_end, uint16_t y_end);
void LCD_SetXY(uint16_t x, uint16_t y);
void LCD_Clear(uint16_t color);
void Gui_DrawPoint(uint16_t x, uint16_t y, uint16_t color);

// DMA ���ͺ������ؼ���
void LCD_DMA_Send(uint8_t *data, uint16_t size);

#endif
