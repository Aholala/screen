#include "LCD_Driver.h"
#include "Delay.h"

// ȫ�ֱ��������ڵȴ�DMA���
volatile uint8_t dma_tc_flag = 0;

// DMA�жϷ���������ѡ����������ѯ���򵥣�
void DMA1_Channel3_IRQHandler(void)
{
    if (DMA_GetITStatus(DMA1_IT_TC3) != RESET)
    {
        dma_tc_flag = 1;
        DMA_ClearITPendingBit(DMA1_IT_TC3);
    }
}

// ��ʼ��GPIO��SPI1 �� DMA
void LCD_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    SPI_InitTypeDef SPI_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_SPI1, ENABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE); // ����DMAʱ��

    // === SPI1: PA5 (SCK), PA7 (MOSI) ===
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5 | GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // === ��������: PB0, PB1, PB10, PB11 ===
    GPIO_InitStructure.GPIO_Pin = LCD_RST_PIN | LCD_RS_PIN | LCD_CS_PIN | LCD_LED_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    // ��ʼ״̬
    LCD_CS_SET;
    LCD_RS_SET;
    LCD_RST_SET;
    LCD_LED_SET;

    // === ����SPI1��Mode 0��===
    SPI_InitStructure.SPI_Direction = SPI_Direction_1Line_Tx; // ֻ����
    SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
    SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
    SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
    SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
    SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
    SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_8; // 9MHz
    SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
    SPI_InitStructure.SPI_CRCPolynomial = 7;
    SPI_Init(SPI1, &SPI_InitStructure);

    // ����SPI TX��DMA����
    SPI_I2S_DMACmd(SPI1, SPI_I2S_DMAReq_Tx, ENABLE);
    SPI_Cmd(SPI1, ENABLE);
}

// ��ʼ��DMA��Channel3 �� SPI1_TX��
void LCD_DMA_Init(void)
{
    DMA_InitTypeDef DMA_InitStructure;

    // ����DMA1 Channel3����ӦSPI1_TX��
    DMA_DeInit(DMA1_Channel3);
    DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&(SPI1->DR);
    DMA_InitStructure.DMA_MemoryBaseAddr = 0; // ��̬����
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
    DMA_InitStructure.DMA_BufferSize = 0;     // ��̬����
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
    DMA_InitStructure.DMA_Priority = DMA_Priority_High;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(DMA1_Channel3, &DMA_InitStructure);

    // ��ѡ�����ô�������жϣ���������ѯ������ע�͵���
    // DMA_ITConfig(DMA1_Channel3, DMA_IT_TC, ENABLE);
    // NVIC_EnableIRQ(DMA1_Channel3_IRQn);
}

// ʹ��DMA�������ݣ�����ʽ���ȴ���ɣ�
void LCD_DMA_Send(uint8_t *data, uint16_t size)
{
    // �ر�DMAͨ������ȫ�����
    DMA_Cmd(DMA1_Channel3, DISABLE);
    
    // �����ڴ��ַ������
    DMA1_Channel3->CMAR = (uint32_t)data;
    DMA1_Channel3->CNDTR = size;
    
    // �����־����Ҫ����
    DMA_ClearFlag(DMA1_FLAG_TC3 | DMA1_FLAG_TE3 | DMA1_FLAG_HT3);
    
    // ����DMA
    DMA_Cmd(DMA1_Channel3, ENABLE);

    // ��ѯ�ȴ��������
    while (DMA_GetFlagStatus(DMA1_FLAG_TC3) == RESET);
    
    // ȷ��SPI FIFO�գ���ֹCS���߹��磩
    while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_BSY) == SET);
}

// д�������DMA��С��������
void LCD_WriteIndex(uint8_t reg)
{
    LCD_CS_CLR;
    LCD_RS_CLR;
    while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET);
    SPI_I2S_SendData(SPI1, reg);
    while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_BSY) == SET);
    LCD_CS_SET;
}

// д8λ���ݣ�����DMA��
void LCD_WriteData(uint8_t data)
{
    LCD_CS_CLR;
    LCD_RS_SET;
    while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET);
    SPI_I2S_SendData(SPI1, data);
    while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_BSY) == SET);
    LCD_CS_SET;
}

// д16λ���ݣ�����DMA��
void LCD_WriteData_16Bit(uint16_t data)
{
    LCD_CS_CLR;
    LCD_RS_SET;
    while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET);
    SPI_I2S_SendData(SPI1, data >> 8);
    while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET);
    SPI_I2S_SendData(SPI1, data & 0xFF);
    while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_BSY) == SET);
    LCD_CS_SET;
}

// д�Ĵ���
void LCD_WriteReg(uint8_t reg, uint8_t data)
{
    LCD_WriteIndex(reg);
    LCD_WriteData(data);
}

// ������ʾ����
void LCD_SetRegion(uint16_t x_start, uint16_t y_start, uint16_t x_end, uint16_t y_end)
{
    LCD_WriteIndex(0x2A);
    LCD_CS_CLR;
    LCD_RS_SET;
    while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET); SPI_I2S_SendData(SPI1, x_start >> 8);
    while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET); SPI_I2S_SendData(SPI1, x_start & 0xFF);
    while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET); SPI_I2S_SendData(SPI1, x_end >> 8);
    while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET); SPI_I2S_SendData(SPI1, x_end & 0xFF);
    while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_BSY) == SET);
    LCD_CS_SET;

    LCD_WriteIndex(0x2B);
    LCD_CS_CLR;
    LCD_RS_SET;
    while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET); SPI_I2S_SendData(SPI1, y_start >> 8);
    while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET); SPI_I2S_SendData(SPI1, y_start & 0xFF);
    while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET); SPI_I2S_SendData(SPI1, y_end >> 8);
    while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET); SPI_I2S_SendData(SPI1, y_end & 0xFF);
    while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_BSY) == SET);
    LCD_CS_SET;

    LCD_WriteIndex(0x2C); // ��ʼдGRAM
}

// ��������
void LCD_SetXY(uint16_t x, uint16_t y)
{
    LCD_SetRegion(x, y, x, y);
}

// ��λ
void LCD_Reset(void)
{
    LCD_RST_CLR;
    Delay_ms(100);
    LCD_RST_SET;
    Delay_ms(120);
}

// ��ʼ��
void LCD_Init(void)
{
    LCD_GPIO_Init();
    LCD_DMA_Init();
    LCD_Reset();

    LCD_WriteIndex(0x11); Delay_ms(120);
    LCD_WriteIndex(0xB1); LCD_WriteData(0x01); LCD_WriteData(0x2C); LCD_WriteData(0x2D);
    LCD_WriteIndex(0xB2); LCD_WriteData(0x01); LCD_WriteData(0x2C); LCD_WriteData(0x2D);
    LCD_WriteIndex(0xB3); LCD_WriteData(0x01); LCD_WriteData(0x2C); LCD_WriteData(0x2D); LCD_WriteData(0x01); LCD_WriteData(0x2C); LCD_WriteData(0x2D);
    LCD_WriteIndex(0xB4); LCD_WriteData(0x07);
    LCD_WriteIndex(0xC0); LCD_WriteData(0xA2); LCD_WriteData(0x02); LCD_WriteData(0x84);
    LCD_WriteIndex(0xC1); LCD_WriteData(0xC5);
    LCD_WriteIndex(0xC2); LCD_WriteData(0x0A); LCD_WriteData(0x00);
    LCD_WriteIndex(0xC3); LCD_WriteData(0x8A); LCD_WriteData(0x2A);
    LCD_WriteIndex(0xC4); LCD_WriteData(0x8A); LCD_WriteData(0xEE);
    LCD_WriteIndex(0xC5); LCD_WriteData(0x0E);
    LCD_WriteIndex(0x36); LCD_WriteData(0xC0);
    LCD_WriteIndex(0xE0); LCD_WriteData(0x0F); LCD_WriteData(0x1A); LCD_WriteData(0x0F); LCD_WriteData(0x18); LCD_WriteData(0x2F); LCD_WriteData(0x28); LCD_WriteData(0x20); LCD_WriteData(0x22); LCD_WriteData(0x1F); LCD_WriteData(0x1B); LCD_WriteData(0x23); LCD_WriteData(0x37); LCD_WriteData(0x00); LCD_WriteData(0x07); LCD_WriteData(0x02); LCD_WriteData(0x10);
    LCD_WriteIndex(0xE1); LCD_WriteData(0x0F); LCD_WriteData(0x1B); LCD_WriteData(0x0F); LCD_WriteData(0x17); LCD_WriteData(0x33); LCD_WriteData(0x2C); LCD_WriteData(0x29); LCD_WriteData(0x2E); LCD_WriteData(0x30); LCD_WriteData(0x30); LCD_WriteData(0x39); LCD_WriteData(0x3F); LCD_WriteData(0x00); LCD_WriteData(0x07); LCD_WriteData(0x03); LCD_WriteData(0x10);
    LCD_WriteIndex(0x3A); LCD_WriteData(0x05);
    LCD_WriteIndex(0x29);
    LCD_LED_SET;
}

// ������ʹ��DMA���٣�
void LCD_Clear(uint16_t color)
{
    const uint32_t total_pixels = X_MAX_PIXEL * Y_MAX_PIXEL;
    static uint8_t buffer[256]; // С����������������飨��ʡRAM��

    LCD_SetRegion(0, 0, X_MAX_PIXEL - 1, Y_MAX_PIXEL - 1);
    LCD_CS_CLR;
    LCD_RS_SET;

    uint8_t high = (uint8_t)(color >> 8);
    uint8_t low  = (uint8_t)(color & 0xFF);

    // �ֿ鷢�ͣ������bufferռ�ù���RAM��
    for (uint32_t i = 0; i < total_pixels * 2; i += sizeof(buffer))
    {
        uint16_t chunk = (total_pixels * 2 - i) > sizeof(buffer) ? sizeof(buffer) : (total_pixels * 2 - i);
        for (uint16_t j = 0; j < chunk; j += 2)
        {
            buffer[j] = high;
            buffer[j + 1] = low;
        }
        LCD_DMA_Send(buffer, chunk);
    }

    LCD_CS_SET;
}

// ���㣨С���ݣ�����DMA��
void Gui_DrawPoint(uint16_t x, uint16_t y, uint16_t color)
{
    if (x >= X_MAX_PIXEL || y >= Y_MAX_PIXEL) return;
    LCD_SetXY(x, y);
    LCD_WriteData_16Bit(color);
}
