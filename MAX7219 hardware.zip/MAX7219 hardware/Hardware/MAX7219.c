#include "stm32f10x.h"                  // Device header
#include "MAX7219.h"
#include "Delay.h"

/* �������� */
// ʹ��Ӳ�� SPI2: PB12-CS, PB13-SCK, PB15-MOSI
#define MAX7219_CS(x)		GPIO_WriteBit(GPIOB, GPIO_Pin_12, (BitAction)(x))

//-------------------------------------------------------------------------------------------------------------------
// �������     ��ʼ�� MAX7219 ����� GPIO ����
// ����˵��     void
// ���ز���     void
// ʹ��ʾ��     MAX7219_GPIO_Init(); // ͨ���� MAX7219_Init() ����
// ��ע��Ϣ     ����Ӳ�� SPI2 �ӿ�
//-------------------------------------------------------------------------------------------------------------------
void MAX7219_GPIO_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	
	// CS: PB12 (�������)
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	// SCK: PB13, MOSI: PB15 (�����������)
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	// SPI2 ����
	SPI_InitTypeDef SPI_InitStructure;
	SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
	SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
	SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
	SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
	SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
	SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
	SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_16; // Ƶ�ʲ��˹���
	SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
	SPI_InitStructure.SPI_CRCPolynomial = 7;
	SPI_Init(SPI2, &SPI_InitStructure);
	
	SPI_Cmd(SPI2, ENABLE);
	
	MAX7219_CS(1); // Ĭ�ϲ�ѡ��
}

//-------------------------------------------------------------------------------------------------------------------
// �������     ����һ���ֽ����ݵ� MAX7219
// ����˵��     data: Ҫ���͵�8λ����
// ���ز���     void
// ʹ��ʾ��     MAX7219_SendByte(0xA5);
// ��ע��Ϣ     ʹ��Ӳ�� SPI2 ��������
//-------------------------------------------------------------------------------------------------------------------
void MAX7219_SendByte(uint8_t data)
{
	while (SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_TXE) == RESET); // �ȴ���������
	SPI_I2S_SendData(SPI2, data);
	while (SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_RXNE) == RESET); // �ȴ��������ǿգ�������ɱ�־��
	SPI_I2S_ReceiveData(SPI2); // ����������־λ
}

//-------------------------------------------------------------------------------------------------------------------
// �������     �� MAX7219 ���ͼĴ�����ַ������
// ����˵��     reg: �Ĵ�����ַ��0x00~0x0F����data: Ҫд�������
// ���ز���     void
// ʹ��ʾ��     MAX7219_SendData(0x01, 0xFF); // ������һ��
// ��ע��Ϣ     �Զ�����Ƭѡ�źţ�������Ӳ�� SPI
//-------------------------------------------------------------------------------------------------------------------
void MAX7219_SendData(uint8_t reg, uint8_t data)
{
    MAX7219_CS(0);  
    
    MAX7219_SendByte(reg);  
    MAX7219_SendByte(data); 
    
    MAX7219_CS(1);  
}

// --- ���º����߼�������ԭ��һ�£�ע�Ͳ������� ---

void LightRows(uint16_t delay_time) 
{
    uint8_t display_data[8] = {0};  
    for (uint8_t row = 1; row <= 8; row++) 
	{
        for (uint8_t col = 1; col <= 8; col++) 
		{
            display_data[col - 1] |= (1 << (row - 1));  
            MAX7219_SendData(col, display_data[col - 1]); 
            Delay_ms(delay_time);  
        }
    }
}

void LightColumns(uint16_t delay_time) 
{
    for (uint8_t row = 1; row <= 8; row++) 
	{
        for (uint8_t col = 1; col <= 8; col++) 
		{
            MAX7219_ClearDisplay();  
            MAX7219_SendData(col, (1 << (row - 1)));  
            Delay_ms(delay_time);  
        }
    }
}

void MAX7219_SetBrightness(uint8_t brightness)
{
    if (brightness > 15) brightness = 15;  
    MAX7219_SendData(0x0A, brightness);  
}

void MAX7219_LightALL(void) 
{
    for (uint8_t i = 1; i <= 8; i++) MAX7219_SendData(i, 0xFF);  
}

void MAX7219_DisplayRow(uint8_t row, uint8_t data)
{
    if (row >= 1 && row <= 8) MAX7219_SendData(row, data); 
}

void MAX7219_ClearDisplay(void)
{
    for (uint8_t col = 1; col <= 8; col++) MAX7219_SendData(col, 0x00);  
}

void MAX7219_Init(void)
{
	MAX7219_GPIO_Init();
    MAX7219_SendData(0x09, 0x00); 
    MAX7219_SendData(0x0A, 0x08); 
    MAX7219_SendData(0x0B, 0x07); 
    MAX7219_SendData(0x0C, 0x01); 
    MAX7219_SendData(0x0F, 0x00); 
	MAX7219_ClearDisplay();
}

void LightColumnsFull(uint16_t delay_time) 
{
    for (uint8_t col = 1; col <= 8; col++) 
	{
        MAX7219_SendData(col, 0xFF);
        Delay_ms(delay_time);
    }
}

void LightDiagonal(uint16_t delay_time) 
{
    MAX7219_ClearDisplay();
    for (uint8_t i = 0; i < 8; i++) 
	{
        MAX7219_DisplayRow(i + 1, (1 << i)); 
        Delay_ms(delay_time);
    }
}

void LightAntiDiagonal(uint16_t delay_time) 
{
    MAX7219_ClearDisplay();
    for (uint8_t i = 0; i < 8; i++) 
	{
        MAX7219_DisplayRow(i + 1, (1 << (7 - i))); 
        Delay_ms(delay_time);
    }
}

void BreathingEffect(uint16_t cycle_ms) 
{
    uint16_t step_delay = cycle_ms / 30;
    if (step_delay < 1) step_delay = 1;
    MAX7219_LightALL(); 
    for (uint8_t b = 0; b <= 15; b++) 
	{
        MAX7219_SetBrightness(b);
        Delay_ms(step_delay);
    }
    for (uint8_t b = 15; b > 0; b--) 
	{
        MAX7219_SetBrightness(b - 1);
        Delay_ms(step_delay);
    }
    MAX7219_SetBrightness(8); 
}

void ShowPattern(const uint8_t *pattern) 
{
    for (uint8_t row = 0; row < 8; row++) MAX7219_DisplayRow(row + 1, pattern[row]);
}

void ScrollCharLeft(const uint8_t *pattern, uint16_t delay_time) 
{
    for (int offset = 8; offset >= -8; offset--) 
	{
        for (int row = 0; row < 8; row++) 
		{
            uint8_t data = 0;
            if (offset >= 0 && offset < 8) data = pattern[row] >> offset;
            else if (offset < 0) 
			{
                int shift = -offset;
                if (shift < 8) data = (uint8_t)(pattern[row] << shift);
            }
            MAX7219_DisplayRow(row + 1, data);
        }
        Delay_ms(delay_time);
    }
    MAX7219_ClearDisplay();
}

void BlinkAll(uint16_t on_time, uint16_t off_time, uint8_t count) 
{
    for (uint8_t i = 0; i < count; i++) 
	{
        MAX7219_LightALL();
        Delay_ms(on_time);
        MAX7219_ClearDisplay();
        Delay_ms(off_time);
    }
}

void ShowCheckerboard(void) 
{
    for (uint8_t row = 1; row <= 8; row++) 
	{
        MAX7219_DisplayRow(row, (row % 2 == 1) ? 0x55 : 0xAA);
    }
}

void ShowHeart(void) { const uint8_t p[8] = {0x00, 0x66, 0xFF, 0xFF, 0xFF, 0x7E, 0x3C, 0x18}; ShowPattern(p); }
void ShowSmiley(void) { const uint8_t p[8] = {0x3C, 0x7E, 0xDB,0xFF, 0xDB, 0xC3, 0x7E, 0x3C}; ShowPattern(p); }
void ShowSad(void) { const uint8_t p[8] = {0x3C, 0x7E, 0xDB, 0xFF, 0xDB, 0xDB, 0x7E, 0x3C}; ShowPattern(p); }
void ShowStar(void) { const uint8_t p[8] = {0x18, 0x3C, 0x7E, 0xFF, 0x7E, 0x3C, 0x18, 0x00}; ShowPattern(p); }
void ShowSquare(void) { const uint8_t p[8] = {0x7E, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x7E}; ShowPattern(p); }
void ShowDiamond(void) { const uint8_t p[8] = {0x10, 0x38, 0x7C, 0xFE, 0x7C, 0x38, 0x10, 0x00}; ShowPattern(p); }
void ShowArrowRight(void) { const uint8_t p[8] = {0x00, 0x04, 0x0C, 0x1E, 0x3F, 0x1E, 0x0C, 0x04}; ShowPattern(p); }
void ShowArrowLeft(void) { const uint8_t p[8] = {0x00, 0x20, 0x30, 0x38, 0x3C, 0x38, 0x30, 0x20}; ShowPattern(p); }
void ShowArrowUp(void) { const uint8_t p[8] = {0x00, 0x08, 0x1C, 0x3E, 0x7F, 0x08, 0x08, 0x08}; ShowPattern(p); }
void ShowArrowDown(void) { const uint8_t p[8] = {0x08, 0x08, 0x08, 0x7F, 0x3E, 0x1C, 0x08, 0x00}; ShowPattern(p); }
void ShowCircle(void) { const uint8_t p[8] = {0x3C, 0x66, 0xDB, 0xDB, 0xDB, 0xDB, 0x66, 0x3C}; ShowPattern(p); }

void ShowAllPatterns(void)
{
    ShowHeart(); Delay_ms(800); MAX7219_ClearDisplay(); Delay_ms(200);
    ShowSmiley(); Delay_ms(800); MAX7219_ClearDisplay(); Delay_ms(200);
    ShowSad(); Delay_ms(800); MAX7219_ClearDisplay(); Delay_ms(200);
    ShowStar(); Delay_ms(800); MAX7219_ClearDisplay(); Delay_ms(200);
    ShowSquare(); Delay_ms(800); MAX7219_ClearDisplay(); Delay_ms(200);
    ShowDiamond(); Delay_ms(800); MAX7219_ClearDisplay(); Delay_ms(200);
    ShowArrowRight(); Delay_ms(800); MAX7219_ClearDisplay(); Delay_ms(200);
    ShowArrowLeft(); Delay_ms(800); MAX7219_ClearDisplay(); Delay_ms(200);
    ShowArrowUp(); Delay_ms(800); MAX7219_ClearDisplay(); Delay_ms(200);
    ShowArrowDown(); Delay_ms(800); MAX7219_ClearDisplay(); Delay_ms(200);
    ShowCircle(); Delay_ms(800); MAX7219_ClearDisplay(); Delay_ms(200);
}
