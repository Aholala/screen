#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "MAX7219.h"

int main(void)
{	
    MAX7219_Init();

    while (1)
    {
        // 1. ������ˮ��Ч��
        LightRows(50);
        MAX7219_ClearDisplay();
        Delay_ms(200); 

        // 2. ������ˮ��Ч��
        LightColumns(50);
        MAX7219_ClearDisplay();
        Delay_ms(200); 

        // 3. ���ϵ���ɨ��Ч��
        for (uint8_t i = 1; i <= 8; i++)
        {
            MAX7219_ClearDisplay();
            MAX7219_SendData(i, 0xFF);  
            Delay_ms(50);
        }
        MAX7219_ClearDisplay();
        Delay_ms(200); 

        // 4. ���µ���ɨ��Ч��
        for (uint8_t i = 8; i >= 1; i--)
        {
            MAX7219_ClearDisplay();
            MAX7219_SendData(i, 0xFF);  
            Delay_ms(50);
        }
        MAX7219_ClearDisplay();
        Delay_ms(200); 

        // 5. ���е���������
        for (uint8_t i = 1; i <= 8; i++)
        {
            MAX7219_SendData(i, 0xFF);  
            Delay_ms(50);
        }
        MAX7219_ClearDisplay();
        Delay_ms(200); 

        // 6. ���ȵ���Ч��
        for (uint8_t j = 0; j < 3; j++) 
        {
            for (uint8_t i = 1; i <= 8; i++)
            {
                MAX7219_ClearDisplay();
                MAX7219_SendData(i, 0xFF);  
                uint8_t brightness = ((i * 2) > 15) ? 15 : i * 2;
                MAX7219_SetBrightness(brightness);
                Delay_ms(100);
            }
            MAX7219_ClearDisplay();
            MAX7219_SetBrightness(8); 
            Delay_ms(200); 
        }

        // 7-12. ����Ч��
        LightDiagonal(100); MAX7219_ClearDisplay(); Delay_ms(200);
        LightAntiDiagonal(100); MAX7219_ClearDisplay(); Delay_ms(200);
        ShowCheckerboard(); Delay_ms(1000); MAX7219_ClearDisplay(); Delay_ms(200);
        BreathingEffect(2000); Delay_ms(200);
        BlinkAll(100, 100, 5); Delay_ms(200);
        LightColumnsFull(100); MAX7219_ClearDisplay(); Delay_ms(200);

        // 13. ��ʾ����ͼ��
        ShowAllPatterns();

        // 14. �����ַ�Ч��
        const uint8_t heart_pattern[8] = {0x00, 0x66, 0xFF, 0xFF, 0xFF, 0x7E, 0x3C, 0x18};
        ScrollCharLeft(heart_pattern, 50);
        Delay_ms(200);
    }
}
