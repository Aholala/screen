#include "LCD_Driver.h"
#include "Delay.h"

// Һ��IO��ʼ������
void LCD_GPIO_Init(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;
    
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB, ENABLE);
    
    GPIO_InitStructure.GPIO_Pin = LCD_SCL | LCD_SDA;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin = LCD_RST | LCD_RS | LCD_CS | LCD_LED;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    
    LCD_CS_SET;
    LCD_SCL_SET;
    LCD_SDA_SET;
    LCD_LED_SET; 
}

// ����SPI�����ֽ�
void SPI_WriteData(u8 Data)
{
    unsigned char i = 0;
    for(i=0; i<8; i++)
    {
        LCD_SCL_CLR;
        if(Data & 0x80) LCD_SDA_SET;
        else LCD_SDA_CLR;
        for(volatile int d=0; d<1; d++); 
        LCD_SCL_SET;
        for(volatile int d=0; d<1; d++);
        Data <<= 1;
    }
}

void LCD_WriteIndex(u8 Index)
{
    LCD_CS_CLR;
    LCD_RS_CLR;
    SPI_WriteData(Index);
    LCD_CS_SET;
}

void LCD_WriteData(u8 Data)
{
    LCD_CS_CLR;
    LCD_RS_SET;
    SPI_WriteData(Data);
    LCD_CS_SET; 
}

void LCD_WriteData_16Bit(u16 Data)
{
    LCD_CS_CLR;
    LCD_RS_SET;
    SPI_WriteData(Data >> 8);
    SPI_WriteData(Data & 0xFF);
    LCD_CS_SET; 
}

void LCD_WriteReg(u8 Index, u8 Data)
{
    LCD_WriteIndex(Index);
    LCD_WriteData(Data);
}

void LCD_Reset(void)
{
    LCD_RST_CLR;
    Delay_ms(100);
    LCD_RST_SET;
    Delay_ms(50);
}

void LCD_SetRegion(u16 x_start, u16 y_start, u16 x_end, u16 y_end)
{		
    LCD_WriteIndex(0x2a); 
    LCD_CS_CLR;
    LCD_RS_SET;
    SPI_WriteData(x_start >> 8);
    SPI_WriteData(x_start & 0xFF);
    SPI_WriteData(x_end >> 8);
    SPI_WriteData(x_end & 0xFF);
    LCD_CS_SET;

    LCD_WriteIndex(0x2b); 
    LCD_CS_CLR;
    LCD_RS_SET;
    SPI_WriteData(y_start >> 8);
    SPI_WriteData(y_start & 0xFF);
    SPI_WriteData(y_end >> 8);
    SPI_WriteData(y_end & 0xFF);
    LCD_CS_SET;
    
    LCD_WriteIndex(0x2c); 
}

void LCD_SetXY(u16 x, u16 y)
{
    LCD_SetRegion(x, y, x, y);
}

void LCD_Init(void)
{	
    LCD_GPIO_Init();
    LCD_Reset(); 

    LCD_WriteIndex(0x11); // Sleep exit 
    Delay_ms(120);
        
    LCD_WriteIndex(0xB1); 
    LCD_WriteData(0x01); LCD_WriteData(0x2C); LCD_WriteData(0x2D); 
    LCD_WriteIndex(0xB2); 
    LCD_WriteData(0x01); LCD_WriteData(0x2C); LCD_WriteData(0x2D); 
    LCD_WriteIndex(0xB3); 
    LCD_WriteData(0x01); LCD_WriteData(0x2C); LCD_WriteData(0x2D); 
    LCD_WriteData(0x01); LCD_WriteData(0x2C); LCD_WriteData(0x2D); 
    
    LCD_WriteIndex(0xB4); 
    LCD_WriteData(0x07); 
    
    LCD_WriteIndex(0xC0); 
    LCD_WriteData(0xA2); LCD_WriteData(0x02); LCD_WriteData(0x84); 
    LCD_WriteIndex(0xC1); 
    LCD_WriteData(0xC5); 
    LCD_WriteIndex(0xC2); 
    LCD_WriteData(0x0A); LCD_WriteData(0x00); 
    LCD_WriteIndex(0xC3); 
    LCD_WriteData(0x8A); LCD_WriteData(0x2A); 
    LCD_WriteIndex(0xC4); 
    LCD_WriteData(0x8A); LCD_WriteData(0xEE); 
    
    LCD_WriteIndex(0xC5); 
    LCD_WriteData(0x0E); 
    
    // --- ��ɫ�������Ĳ��� ---
    LCD_WriteIndex(0x36); 
    // ԭ���� 0xC8 (BGR˳��)����Ϊ 0xC0 (RGB˳��) ���������ת����
    LCD_WriteData(0xC0); 
    
    LCD_WriteIndex(0xe0); 
    LCD_WriteData(0x0f); LCD_WriteData(0x1a); LCD_WriteData(0x0f); LCD_WriteData(0x18); 
    LCD_WriteData(0x2f); LCD_WriteData(0x28); LCD_WriteData(0x20); LCD_WriteData(0x22); 
    LCD_WriteData(0x1f); LCD_WriteData(0x1b); LCD_WriteData(0x23); LCD_WriteData(0x37); 
    LCD_WriteData(0x00); LCD_WriteData(0x07); LCD_WriteData(0x02); LCD_WriteData(0x10); 

    LCD_WriteIndex(0xe1); 
    LCD_WriteData(0x0f); LCD_WriteData(0x1b); LCD_WriteData(0x0f); LCD_WriteData(0x17); 
    LCD_WriteData(0x33); LCD_WriteData(0x2c); LCD_WriteData(0x29); LCD_WriteData(0x2e); 
    LCD_WriteData(0x30); LCD_WriteData(0x30); LCD_WriteData(0x39); LCD_WriteData(0x3f); 
    LCD_WriteData(0x00); LCD_WriteData(0x07); LCD_WriteData(0x03); LCD_WriteData(0x10);  
    
    LCD_WriteIndex(0x3A); 
    LCD_WriteData(0x05); 
    
    LCD_WriteIndex(0x29); // Display on	 
}

void Gui_DrawPoint(u16 x, u16 y, u16 Color)
{
    LCD_SetXY(x, y);
    LCD_WriteData_16Bit(Color);
}    

// �Ż���������ɫ�Ŀ�������
void LCD_Clear(u16 Color)               
{	
    u32 i;
    u32 total_pixels = X_MAX_PIXEL * Y_MAX_PIXEL;
    
    // Ԥ�Ȳ����ɫ�ֽڣ�����ѭ���ڼ���
    u8 high = (u8)(Color >> 8);
    u8 low  = (u8)(Color & 0xFF);
    
    LCD_SetRegion(0, 0, X_MAX_PIXEL - 1, Y_MAX_PIXEL - 1);
    
    LCD_CS_CLR;
    LCD_RS_SET; 
    
    for(i = 0; i < total_pixels; i++)
    {	
        // ���͸��ֽ�
        u8 temp_h = high;
        for(u8 j=0; j<8; j++) {
            LCD_SCL_CLR;
            if(temp_h & 0x80) LCD_SDA_SET; else LCD_SDA_CLR;
            LCD_SCL_SET;
            temp_h <<= 1;
        }
        // ���͵��ֽ�
        u8 temp_l = low;
        for(u8 j=0; j<8; j++) {
            LCD_SCL_CLR;
            if(temp_l & 0x80) LCD_SDA_SET; else LCD_SDA_CLR;
            LCD_SCL_SET;
            temp_l <<= 1;
        }
    }
    LCD_CS_SET;
}
