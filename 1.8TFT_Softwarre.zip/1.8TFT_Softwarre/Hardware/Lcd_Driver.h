#ifndef __LCD_DRIVER_H
#define __LCD_DRIVER_H

#include "stm32f10x.h"                  // Device header

#define X_MAX_PIXEL	        128
#define Y_MAX_PIXEL	        160

// ��ɫ����
#define RED     0xf800
#define GREEN   0x07e0
#define BLUE    0x001f
#define WHITE   0xffff
#define BLACK   0x0000
#define YELLOW  0xFFE0
#define GRAY0   0xEF7D   	
#define GRAY1   0x8410      
#define GRAY2   0x4208      


//-----------------LCD�˿ڶ���-----------------

// Group A: SCL, SDA
#define LCD_CTRL_A      GPIOA
#define LCD_SCL         GPIO_Pin_6  // PA6
#define LCD_SDA         GPIO_Pin_7  // PA7

// Group B: RES, RS, CS, LED
#define LCD_CTRL_B      GPIOB
#define LCD_RST         GPIO_Pin_0  // PB0
#define LCD_RS          GPIO_Pin_1  // PB1
#define LCD_CS          GPIO_Pin_10 // PB10
#define LCD_LED         GPIO_Pin_11 // PB11

//-----------------LCD���ƺ�-----------------

// SCL & SDA (Port A)
#define LCD_SCL_SET     LCD_CTRL_A->BSRR = LCD_SCL
#define LCD_SCL_CLR     LCD_CTRL_A->BRR  = LCD_SCL

#define LCD_SDA_SET     LCD_CTRL_A->BSRR = LCD_SDA
#define LCD_SDA_CLR     LCD_CTRL_A->BRR  = LCD_SDA

// RST, RS, CS, LED (Port B)
#define LCD_RST_SET     LCD_CTRL_B->BSRR = LCD_RST
#define LCD_RST_CLR     LCD_CTRL_B->BRR  = LCD_RST

#define LCD_RS_SET      LCD_CTRL_B->BSRR = LCD_RS
#define LCD_RS_CLR      LCD_CTRL_B->BRR  = LCD_RS

#define LCD_CS_SET      LCD_CTRL_B->BSRR = LCD_CS
#define LCD_CS_CLR      LCD_CTRL_B->BRR  = LCD_CS

#define LCD_LED_SET     LCD_CTRL_B->BSRR = LCD_LED
#define LCD_LED_CLR     LCD_CTRL_B->BRR  = LCD_LED

// ����������ȫ�� Lcd_ ��Ϊ LCD_��
void LCD_GPIO_Init(void);
void LCD_WriteIndex(u8 Index);
void LCD_WriteData(u8 Data);
void LCD_WriteReg(u8 Index, u8 Data);
void LCD_Reset(void);
void LCD_Init(void);
void LCD_Clear(u16 Color);
void LCD_SetXY(u16 x, u16 y);
void Gui_DrawPoint(u16 x, u16 y, u16 Data);        // ע�⣺�˺������� GUI �㣬����ԭ��
void LCD_SetRegion(u16 x_start, u16 y_start, u16 x_end, u16 y_end);
void LCD_WriteData_16Bit(u16 Data);

#endif
